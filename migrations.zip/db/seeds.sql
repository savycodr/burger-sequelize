INSERT INTO burgers (burger_name, devoured) VALUES ('Bacon Avocado', true);
INSERT INTO burgers (burger_name, devoured) VALUES ('Texas Turkey Burger', false);
INSERT INTO burgers (burger_name, devoured) VALUES ('Cheddar Power Burger', true);
